(function () {
    if (document.getElementsByClassName('.page-node-type-manuals')) {

        // left column scroll to active item
        var manuals_menu_item_active = document.querySelector(".page-node-type-manuals .menu-item--active-trail");
        manuals_menu_item_active.scrollIntoView();

        
    }



})();;
