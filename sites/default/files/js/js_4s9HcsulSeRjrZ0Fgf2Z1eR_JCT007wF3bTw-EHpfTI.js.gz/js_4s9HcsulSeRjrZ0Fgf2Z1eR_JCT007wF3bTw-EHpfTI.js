(function () {
    var manuals_menu_item_active = document.querySelector(".page-node-type-manuals .menu-item--active-trail");
    if (manuals_menu_item_active) {
        manuals_menu_item_active.scrollIntoView();
    }
})();;
